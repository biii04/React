import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Newspage from './components/NewsPage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='*' element={<Newspage />}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
