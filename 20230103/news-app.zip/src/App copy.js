import axios from 'axios';
import styled from 'styled-components';
import { useState } from 'react';

//스타일이 적용된 div태그 생성
// 스타일이 적용된 HTML요소를 생성
// 역따옴표(``)안쪽에 css를 정의하고, 변수를 만들어서 저장시킨다.
// 스타일이 저장된 변수명을 활용하여 Component처럼 사용한다.
const StyledDiv = styled.div`
  width:200px;
  height:50px;
  background-color: red;
`;

const StyledBtn = styled.button`
  background: pink;
  height: 30px;
  text-shadow: 1px 2px 8px black;
`;

const StyledA = styled.a`
  color:red;
  text-decoration:none;
`;

function App() {
  const [data, setData] = useState(null);
  // async, await 미적용
  // -> ajax통신이 완료되기전에 다음 소스코드를 실행시킨다.
  // const onClick = () => {
  //   console.log("실행 1");
  //   const news = axios.get('https://newsapi.org/v2/top-headlines?country=kr&apiKey=a8f0d4f98b2f4e60847d990ca71a8503');
  //   news.then((result) => {
  //     console.log(result);
  //     setData(result.data);
  //   });
  //   console.log("실행 2");
  // }

  //async, await 적용
  // -> ajax통신이 완료된 이후 순차적으로 소스코드를 실행시킨다.
  const onClick = async () => {
    console.log("실행 1");
    try {
      const news = await axios.get('https://newsapi.org/v2/top-headlines?country=kr&apiKey=a8f0d4f98b2f4e60847d990ca71a8503');
      console.log(news);
      setData(news.data);
    } catch (e) {
      console.log(e);
    }
    console.log("실행 2");
  }

  const newsList = [];
  if (data != null) {
    for (const news of data.articles) {
      newsList.push(
        <li key={news.url}>
          <StyledA href={news.url} target='_blank'>{news.title}</StyledA>
        </li>
      )
    }
  }
  return (
    <div>
      <StyledDiv>
        <StyledBtn onClick={onClick}>ajax통신하기</StyledBtn>
      </StyledDiv>
      {/* 현재 state값(data)이 null이 아닐경우 textarea태그가 보여지도록 한다. */}
      {
        //JSON.stringify를 그냥 실행하면 데이터가 한줄로만 출력이 되어 
        // 가독성이 좋지 않다.
        data &&
        <textarea rows={20} cols={50} readOnly={true}
          value={JSON.stringify(data)}></textarea>
      }
      {
        //JSON.stringify에 매개변수를 추가하여 가독성 향상
        data &&
        <textarea rows={20} cols={50} readOnly={true}
          value={JSON.stringify(data, null, 2)}></textarea>
      }

      <ul>
        {newsList}
      </ul>
    </div>
  );
}

export default App;
