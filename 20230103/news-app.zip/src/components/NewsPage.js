import NewsList from './NewsList';
import Categories from './Categories';
import { useParams } from 'react-router-dom';

function NewsPage() {
  // const [category, setCategory] = useState('all');
  // const onSelect = useCallback(
  //   category => setCategory(category),
  //   [category]
  // )

  const param = useParams();
  const category = param["*"] || "all";
  return (
    <>
      <Categories category={category}></Categories>
      <NewsList category={category}></NewsList>
    </>

  );
}

export default NewsPage;
