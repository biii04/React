import axios from 'axios';
import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import NewsItem from './NewsItem';

const NewsListBlock = styled.div`
  box-sizing: border-box;
  padding-bottom: 3rem;
  width: 768px;
  margin: 0 auto;
  margin-top: 2rem;
  @media screen and (max-width: 768px) {
    width: 100%;
    padding-left: 1rem;
    padding-right: 1rem;
  }
`;

const sampleArticle = {
  title: '제목',
  description: '내용',
  url: 'https://www.naver.com',
  urlToImage: 'https://via.placeholder.com/160'
}


const NewsList = ({ category }) => {
  const [articles, setArticles] = useState(null);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const query = category === 'all' ? '' : `&category=${category}`;
        const response = await axios.get(
          'https://newsapi.org/v2/top-headlines?country=kr&apiKey=a8f0d4f98b2f4e60847d990ca71a8503' +
          `${query}`
        )
        setArticles(response.data.articles);
      } catch (e) {
        console.log(e);
      }
      setLoading(false);
    }
    fetchData();
  }, [category]);

  //loading이 true일때 대기중...이라는 문자열만 출력한다.
  if (loading) {
    return <NewsListBlock>대기중...</NewsListBlock>
  }

  // articles 상태값이 null일경우 
  if (!articles) {
    return null;
  }

  return (
    // 샘플 데이터 확인용
    // <NewsListBlock>
    //   <NewsItem article={sampleArticle} />
    //   <NewsItem article={sampleArticle} />
    //   <NewsItem article={sampleArticle} />
    // </NewsListBlock>

    //배열.map함수의 특성을 이용해서 
    // artilces배열에 컴포넌트가 담겨지도록 재구성한다.
    <NewsListBlock>
      {
        articles.map(article => {
          return <NewsItem key={article.url} article={article} />
        })
      }
    </NewsListBlock>
  );
}

export default NewsList;