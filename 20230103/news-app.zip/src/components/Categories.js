import { NavLink } from 'react-router-dom';
import styled, { css } from 'styled-components';

const categories = [
  { name: 'all', text: '전체보기' },
  { name: 'business', text: '비지니스' },
  { name: 'entertainment', text: '엔터테인먼트' },
  { name: 'health', text: '건강' },
  { name: 'science', text: '과학' },
  { name: 'sports', text: '스포츠' },
  { name: 'technology', text: '기술' },
]

const CategoriesBlock = styled.div`
  display: flex;
  padding: 1rem;
  width: 768px;
  margin: 0 auto;
  @media screen and (max-width: 768px) {
  width: 100%;
  overflow-x: auto;
  }
`;

// const Category = styled.div`
//   font-size: 1.125rem;
//   cursor: pointer;
//   white-space: pre;
//   text-decoration: none;
//   color: inherit;
//   padding-bottom: 0.25rem;
//   &:hover {
//   color: #495057;
//   }
//   & + & {
//   margin-left: 1rem;
//   }

//   // style-components는 내부적으로 props를 받을수 있다.
//   // props에 따라 스타일을 변경할 수 있다.
//   ${props =>
//     props.active && css`
//       font-weight: 600; border-bottom: 2px solid #22b8cf; color: #22b8cf;
//       &:hover {
//         color: #3bc9db;
//       }`
//   }
// `;

const Category = styled(NavLink)`
  font-size: 1.125rem;
  cursor: pointer;
  white-space: pre;
  text-decoration: none;
  color: inherit;
  padding-bottom: 0.25rem;
  &:hover {
  color: #495057;
  }
  & + & {
  margin-left: 1rem;
  }

  &.active{
    font-weight: 600; border-bottom: 2px solid #22b8cf; color: #22b8cf;
      &:hover {
        color: #3bc9db;
      }
  }
`;

const Categories = ({ onSelect, category }) => {
  return (
    // <CategoriesBlock>
    //   {categories.map(c => (
    //     <Category key={c.name} active={category === c.name}
    //       onClick={() => { onSelect(c.name) }}>{c.text}</Category>
    //   ))}
    // </CategoriesBlock>

    //Category 소스를 NavLink로 수정
    <CategoriesBlock>
      {categories.map(c => (
        <Category key={c.name}
          to={c.name === 'all' ? '/' : `/${c.name}`}>{c.text}</Category>
      ))}
    </CategoriesBlock>
  );
}

export default Categories;