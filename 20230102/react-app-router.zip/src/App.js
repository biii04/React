import './App.css';
import { BrowserRouter, Routes, Route, Link, NavLink, Outlet, useParams } from 'react-router-dom';
import { useState } from 'react';

function Home() {
  return (
    <div>
      <h2>Home</h2>
      홈 화면 입니다.
    </div>
  );
}

//Topics의 목록을 반복문 이용하여 출력하도록 수정
const contents = [
  { id: 1, title: 'HTML', desc: ' HTML is HyperText Markup Language.' },
  { id: 2, title: 'JS', desc: 'JS is interactive.' },
  { id: 3, title: 'CSS', desc: 'CSS is Styling' }
]

function Topics() {
  const list = [];
  for (let i = 0; i < contents.length; i++) {
    list.push(
      <li key={contents[i].id}>
        <NavLink to={`/topics/${contents[i].id}`}>{contents[i].title}</NavLink>
      </li>
    );
  }
  return (
    <div>
      <h2>Topics</h2>
      토픽 페이지 입니다.
      <ul>
        {list}
      </ul>

      {/* 하위컴포넌트가 보여질 부분 */}
      <Outlet></Outlet>
    </div>
  );
}

function Topic() {
  // useParams함수 : 해당 컴포넌트로 요청이 들어올때 url의 파라미터 데이터를 가져올수있다.
  // ex) 요청주소가 /topics/1 이면 1이 파라미터가 된다. 즉 1이라는 데이터를 가져올수 있다. 
  const { id } = useParams();

  //Contents변수를 활용한 상세페이지로 수정
  let selected_topic = {
    title: '죄송합니다.', desc: '해당 주소는 찾을수 없는 페이지 입니다.(404)'
  };

  //향상된 for문 : for(순회할 변수명 of 타겟배열){순회할 변수명 그대로 배열을 순회한다.}
  for (const topic of contents) {
    if (topic.id === Number(id)) {
      //selected_topic 의 title과 desc의 값을
      // id값이 일치하는 항목의 title과 desc값으로 대체한다.
      selected_topic = topic;
      break;
    }
  }
  return (
    <div>
      <h3>{selected_topic.title}</h3>
      {selected_topic.desc}
    </div>
  );
}

function Contact() {
  return (
    <div>
      <h2>Contact</h2>
      내용 화면 입니다.
    </div>
  )
}

function Login() {
  const [user, setUser] = useState({ id: '', pw: '' });
  return (
    <div>
      <h1>로그인 페이지</h1>
      아이디 : <input type='text' onChange={(e) => {
        setUser({ id: e.target.value, pw: user.pw })
      }}></input>
      <br />
      비밀번호 : <input type='password' onChange={(e) => {
        setUser({ id: user.id, pw: e.target.value })
      }}></input>
      <br />
      <Link to={`/login/result/${user.id}/${user.pw}`}>로그인</Link>

      <Outlet></Outlet>
    </div>
  );
}

function LoginResult() {
  //경로 파라미터가 여러개일때 데이터 얻는 방법 : {}에 ,(콤마)로 구분해서 데이터를 얻는다.
  const { id, pw } = useParams();
  console.log(`id : ${id} , pw : ${pw}`);//문자열 템플릿 적용
  console.log('id : ' + id + ' , pw : ' + pw);//문자열 템플릿 미적용
  //JS의 문자열 템플릿 : `${변수명}` -> 문자열 안에서 변수명을 그대로 사용가능
  // 역따옴표(``) : 키보드 1왼쪽에 있는 따옴표
  return (
    <div>
      <p>아이디 : {id}</p>
      <p>비밀번호 : {pw}</p>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <div>
        <h1>react router dom 예제</h1>

        <ul>
          {/* a태그의 href속성은 페이지를 이동시킬때 새롭게 불러오게 된다.
              따라서, 상태값(state)이 유지되지 않고, 속도 도 저하되는 문제가 있다. */}
          {/* Link : 1. a태그를 Link로 변경, href속성은 to속성으로 변경 
                     2. 새로고침을 안한다.
                     3. 상태값(state)가 유지된다. */}
          {/* NavLink : 1. a태그를 Link로 변경, href속성은 to속성으로 변경 
                        2. 새로고침을 안한다.
                        3. 상태값(state)가 유지된다. 
                        4. 클릭된 항목에만 active라는 class가 추가된다.
                        5. 그외의 항목에는 active클래스가 제거된다. */}
          <li><NavLink to='/'>Home</NavLink></li>
          <li><NavLink to='/topics'>Topics</NavLink></li>
          <li><NavLink to='/contact'>Contact</NavLink></li>
          <li><NavLink to='/login'>Login</NavLink></li>
          {/* 
          컴포넌트를 새롭게 생성하고 react-router-dom을 활용해봅시다.
            1. 주소에 localhost:3000/login이라고 요청했을때 Login컴포넌트가 보여지게한다.
            2. Login컴포넌트 에는 아이디,비밀번호 입력창 그리고 로그인버튼을 생성하고,
            3. 아이디,비밀번호 입력해서 로그인 클릭 했을때,
            4. /login/result 라고하는 url로 요청하고,
            5. 아이디와 비밀번호가 출력되도록 하는 페이지를 생성 해봅시다. 
              path에서 경로파라미터가 여러개일때
              -> :id/:pw 와 같이 /로 구분하도록 한다.
            요약 : 로그인 -> 아이디,비밀번호가 화면에 출력 되도록 */}
        </ul>

        <Routes>
          {/* path에 명시된 주소로 요청을 보내면 element속성에 명시된 컴포넌트가
            출력이 된다. */}
          {/* http://locahost:3000/contact
              절대경로 요청(/topics) ->기본주소값/topics  
                                      http://locahost:3000/topics
              상대경로 요청(topics) -> 현재 url에서 /topics를 붙인다.
                                      http://locahost:3000/contact/topics */}
          {/* 상대경로(/로 시작하지 않을때)  */}
          {/* 절대경로(/가있을때 or http로시작하는 주소값)  */}
          <Route path='/' element={<Home />}></Route>
          <Route path='/topics' element={<Topics />}>
            {/* 하위주소를 입력받을때 해당Route안에 Route를 포함시킨다.
              ex) /topics/1 , /topics/2 와 같이 URL을 요청할때 적용 */}
            {/* <Route path='1' element={<Topic />}></Route>
            <Route path='2' element={<Topic />}></Route>
            <Route path='3' element={<Topic />}></Route> */}

            {/* path=':id' useParams에서 key값(id)을 사용하여 데이터를 조회할수 있도록
              수정 */}
            <Route path=':id' element={<Topic />}></Route>
          </Route>
          <Route path='/contact' element={<Contact />}></Route>
          <Route path='/login' element={<Login />}>
            {/* path='result' -> /login/result로 요청을 받게 된다. */}
            <Route path='result/:id/:pw' element={<LoginResult />}></Route>
          </Route>
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
