import React, { Component } from 'react';
import './App.css'; //css 적용방법
import Subject from './Subject';
import TOC from './TOC';
import Content from './Content';

// ctrl + shift + k : 한줄 삭제
// alt + shift + 방향키 위아래 : 한줄 복사
// alt + 방향키 위아래 : 한줄 이동
// ctrl + / : 주석(처리 or 해제)
class App extends Component {
  // state값 생성시 필수항목 : 
  //  생성자(13~15라인까지의 항목들: 생성자,슈퍼생성자,this.state)
  constructor(props) {
    super(props);
    this.state = {
      selected_content_id: 1,
      mode: 'read',
      welcome: { title: 'welcome', desc: 'Hello, React' },
      subject: { title: 'WEB', sub: 'World Wide Web!' },
      contents: [
        { id: 1, title: 'HTML', desc: 'HTML is for information' },
        { id: 2, title: 'CSS', desc: 'CSS is for design' },
        { id: 3, title: 'JavaScript', desc: 'JS is for interactive.' }
      ]
    }
  }

  findContentById(id) {
    let content;
    for (let i = 0; i < this.state.contents.length; i++) {
      if (id === this.state.contents[i].id) {
        //매개변수 id값과 일치하는 contents를 찾으면 content변수에 저장한다.
        content = this.state.contents[i];
        break;//저장이 끝난후 더이상 for문을 실행하지 않아도 되므로 바로 종료
      }
    }
    return content;//저장이 끝난 content변수를 호출한곳으로 반환해준다.
  }

  render() { //state값이 변경이 되면 재호출된다.
    //state의 mode에 따라서 다른내용이 보여지도록 
    // === : 비교연산할때 타입까지 비교 해준다.
    let title, desc;
    if (this.state.mode === 'welcome') {
      title = this.state.welcome.title;
      desc = this.state.welcome.desc;
    } else if (this.state.mode === 'read') {
      const content = this.findContentById(this.state.selected_content_id);
      title = content.title;
      desc = content.desc;
    }
    return (
      <div className="App">
        {/* 
          html 태그 형식으로 컴포넌트를 적용
          컴포넌트 : 화면에 출력할 내용(요소) js파일로 생성한것.
          이름생성 규칙 : html태그와 구분을 주기위해서, 첫글자는 대문자로 생성(명명)한다.
        */}
        {/* 
          컴포넌트에 데이터 전달 - props : 
          html에 속성을 부여하듯이 넘겨줄 데이터의 이름을 정한뒤 = 뒤에 실제데이터값을
          설정해준다.
          ex) title='WEB'
        */}
        <Subject title={this.state.subject.title} sub={this.state.subject.sub}
          onChangePage={function () {
            this.setState({ mode: 'welcome' });
          }.bind(this)} />
        <TOC contents={this.state.contents}
          onSelect={(id) => {
            this.setState({
              mode: 'read',
              selected_content_id: id
            });
          }}></TOC>
        <Content title={title} desc={desc} />
      </div>
    );
  }
}

export default App;
