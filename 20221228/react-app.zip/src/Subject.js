import { Component } from 'react';

class Subject extends Component {
  render() {
    // this.props.title = "제목 수정 테스트"; -> props에 있는 데이터는 수정이 안됨.
    return (
      <header>
        <h1><a href='/' onClick={function (e) {
          this.props.onChangePage();//App.js에서 작성한 onChangePage에 지정해놓은 함수가 실행
          e.preventDefault(); //HTML요소의 기본동작을 막아준다.
        }.bind(this)}>{this.props.title}</a></h1>
        {this.props.sub}
      </header>


      // <header>
      //   <h1><a href='/' onClick={function (e) {
      //     alert('제목 클릭');
      //     e.preventDefault(); //HTML요소의 기본동작을 막아준다.
      //   }}>{this.props.title}</a></h1>
      //   {this.props.sub}
      // </header>

      // <header>
      //   {/* 
      //     컴포넌트 내부에서 전달받은 데이터 사용시 - props : 
      //     this.props 내부에 있는 데이터의 이름을 활용
      //   */}
      //   <h1>{this.props.title}</h1>
      //   {this.props.sub}
      // </header>
    );
  }
}

export default Subject;