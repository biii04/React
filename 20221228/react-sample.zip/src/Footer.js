import { Component } from 'react';

class Footer extends Component {
  render() {
    const list = [];
    for (let i = 0; i < this.props.desc.length; i++) {
      const desc = this.props.desc[i];
      list.push(
        <h5 key={i} onClick={function (e) {
          this.props.onChangeStyle(e);
        }.bind(this)}>{desc}</h5>
      );
    }
    return (
      //for문을 사용하여 h5태그를 한꺼번에 출력
      <footer>
        {list}
      </footer>

      // for문을 사용하지않고 h5태그 5개를 배치
      // <footer>
      //   <h5>{this.props.desc[0]}</h5>
      //   <h5>{this.props.desc[1]}</h5>
      //   <h5>{this.props.desc[2]}</h5>
      //   <h5>{this.props.desc[3]}</h5>
      //   <h5>{this.props.desc[4]}</h5>
      // </footer>
    );
  }
}

export default Footer;