import './App.css';
import TodoInsert from './components/TodoInsert';
import TodoList from './components/TodoList';
import TodoTemplate from './components/TodoTemplate';
import { React, useState, useRef, useCallback } from 'react';

//데이터 2500개 생성
// JS에서 문자열 템플릿 : `${변수명}`
function createBulkTodos() {
  const array = [];
  for (let i = 1; i <= 2500; i++) {
    array.push({ id: i, text: `할일 테스트 ${i}`, checked: false });
  }
  return array;
}

function App() {
  // 더미데이터 3개만 생성
  // const [todos, setTodos] = useState([
  //   { id: 1, text: '리액트 기초 알아보기', checked: true },
  //   { id: 2, text: '컴포넌트 스타일링', checked: true },
  //   { id: 3, text: '일정관리 앱 만들기', checked: false }
  // ]);

  //데이터 2500개 생성하여 todos상태값(state)에 저장
  const [todos, setTodos] = useState(createBulkTodos());

  // useRef : 고유한 값을 저장할때 사용
  const nextId = useRef(todos.length + 1);

  //사용자가 입력한 값을 할일 목록에 추가
  const onInsert = useCallback((text) => {
    const todo = { id: nextId.current, text, checked: false };
    // setTodos(todos.concat(todo));
    //성능개선을 위한 setTodos 함수형으로 변경
    setTodos(todos => todos.concat(todo));
    nextId.current += 1;
    // nextId.current = nextId.current + 1;
  }, [] // useCallback함수안에서 state또는 props값을 사용하면 
    // useCallback함수에 두번째 인자에 배열로 특정값을 지정해야 최신값을 보장할수있다.
  );

  const onRemove = useCallback((id) => {
    setTodos(
      //배열.filter() : 배열을 순회하면서 요소마다 조건 확인 후 
      //조건을 만족하는 요소로 구성된 배열을 리턴
      todos =>
        todos.filter((todo) => todo.id !== id)
    );
  }, []);

  //... 전개연산자 예시 :
  function sum(x, y, z) {
    return x + y + z
  }
  const numbers = [1, 2, 3];
  console.log(
    '기존 방식의 함수 호출 : ',
    sum(numbers[0], numbers[1], numbers[2])
  );

  console.log(
    '전개 연산자를 이용한 함수 호출 : ',
    sum(...numbers)
  );
  console.log('전개연산자를 이용한 배열 접근 : ', ...numbers);
  console.log('기존방식의 배열 접근 : ', numbers[0], numbers[1], numbers[2]);

  const onToggle = useCallback((id) => {
    setTodos(
      // 배열.map() : 배열을 순회하면서 요소마다 callback함수 적용후 새로운 배열로 리턴 해줌
      // -> 배열의 요소를 수정이 가능
      // ...(전개연산자) : 배열이나 문자열과 같이 순회가 가능한 타입의 데이터 사용가능
      // 데이터를 늘어트려 준다.
      todos =>
        todos.map((todo) =>
          todo.id === id ? { ...todo, checked: !todo.checked } : todo)
    );
  }, []);

  return (
    <TodoTemplate>
      <TodoInsert onInsert={onInsert} />
      <TodoList todos={todos} onRemove={onRemove} onToggle={onToggle} />
    </TodoTemplate>
  );
}

export default App;
