import React from 'react';
import './TodoListItem.css';
import { MdCheckBoxOutlineBlank, MdRemoveCircleOutline, MdCheckBox } from 'react-icons/md';

const TodoListItem = (props) => {
  const { id, text, checked } = props.todo;
  return (
    <div className='TodoListItem'>
      <div className={checked ? 'checkbox checked' : 'checkbox'}
        onClick={() => {
          props.onToggle(id);
        }}>
        {checked ? <MdCheckBox /> : <MdCheckBoxOutlineBlank />}
        <div className='text'>{text}</div>
      </div>
      <div className='remove' onClick={() => {
        props.onRemove(id);
      }}>
        <MdRemoveCircleOutline />
      </div>
    </div>
  );
}

// React.memo() : 이전 props와 현재props를 비교하여 변경 사항이 있을때만 리렌더링
export default React.memo(TodoListItem);