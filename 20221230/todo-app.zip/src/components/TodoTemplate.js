import React from 'react';
import './TodoTemplate.css';

function TodoTemplate({ children }) {
  return (
    <div className='TodoTemplate'>
      <div className='app-title'>일정관리</div>
      <div className='content'>{children}</div>
      {/* 
        부모컴포넌트에서 현재 컴포넌트를 호출할때 컴포넌트 태그사이에 넣은 문자열
        <TodoTemplate>Todo App을 만들자</TodoTemplate>
        -> 문자열이 children이라는 매개변수에 담겨져서 전달된다.
       */}
    </div>
  );
}

export default TodoTemplate;