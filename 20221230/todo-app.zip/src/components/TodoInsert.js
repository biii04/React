import { MdAdd } from 'react-icons/md';
import { React, useState, useCallback } from 'react';
import './TodoInsert.css';

const TodoInsert = (props) => {
  const [value, setValue] = useState('');

  const onChange = useCallback((e) => {
    //컴포넌트가 랜더링 될 때마다 생성하지 않고 재사용
    setValue(e.target.value);
  });

  const onSubmit = useCallback((e) => {
    props.onInsert(value);
    setValue('');
    e.preventDefault();
  }, [value]);

  return (
    <form className='TodoInsert' onSubmit={onSubmit}>
      <input placeholder='할 일을 입력하세요.' value={value}
        onChange={onChange} />
      <button type='submit'>
        <MdAdd />
      </button>
    </form>
  );
}

export default TodoInsert;