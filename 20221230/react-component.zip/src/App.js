import './App.css';
//Component : 클래스형 컴포넌트 생성시 필요
// useEffect : 함수형 컴포넌트에서 lifeCycle함수를 이용하기 위해 
// useState : 함수형 컴포넌트에서 state기능 사용시 필요
// useRef : 함수형 컴포넌트에서 최신 state값 활용을 하기 위해
import { Component, useEffect, useState, useRef } from 'react';

class ClassComp extends Component {
  componentWillUnmount() {
    // console.log("class - componentWillUnmount");
  }

  shouldComponentUpdate() {
    // console.log("class - shouldComponentUpdate"); // update - 1
    return true;
  }

  componentDidUpdate() {
    // console.log("class - componentDidUpdate"); // update - 3
  }

  componentDidMount() {
    // console.log("class - componentDidMount"); //mount - 3
  }
  constructor(props) {
    super(props);
    this.state = {
      number: this.props.initNumber,
      date: new Date().toString()
    }
    // console.log("class - constructor"); //mount - 1
  }
  render() {
    // console.log("class - render"); //mount,update - 2
    // const number = this.props.initNumber;
    return (
      <div className='container'>
        <h2>class형 컴포넌트</h2>
        <p>Number : {this.state.number}</p>
        <button onClick={() => {
          this.setState({ number: Math.random() })
        }}>랜덤</button>
        <p>날짜 : {this.state.date}</p>
        <button onClick={() => {
          this.setState({ date: new Date().toString() });
        }}>날짜갱신</button>
      </div>
    );
  }
}

function FuncComp(props) {//함수의 첫번째 인자값에 props가 담겨져있다.
  // console.log("function - render"); // mount,update-1

  useEffect(function () { //componentDidMount, componentDidUpdate와 동일한 역할
    // console.log("function - useEffect"); //mount,update-2

    return function () {//clean up 함수
      // console.log("function - useEffect의 return")
    }
  });

  // const number = props.initNumber;

  // useState로 생성한 state값에는 두가지 인자가 들어있는데
  // 0번째 항목에는 실제 value값이 들어있고,
  // 1번째 항목에는 해당 state을 변경할수있는 setState함수가 내장되어있다.
  // const numberState = useState(props.initNumber);
  // const number = numberState[0];
  // const setNumber = numberState[1];

  // const [state1 , setState1] = useState(초기값할당);
  // state 에는 상태값이 저장되어있고,
  // setState에는 상태값을 수정할수있는 setState함수가 내장되어있다.
  // setState함수를 호출하면 해당하는 state값이 변경이 된다.(1대1관계)
  const [number, setNumber] = useState(props.initNumber);
  const [date, setDate] = useState(new Date().toString());
  return (
    <div className='container'>
      <h2>Function형 컴포넌트</h2>
      <p>Number : {number}</p>
      <button onClick={() => {
        setNumber(Math.random());
      }}>랜덤</button>
      <p>날짜 : {date}</p>
      <button onClick={() => {
        setDate(new Date().toString());
      }}>날짜갱신</button>
    </div>
  );
}

//라이프사이클 메소드를 활용한 최신 state값 활용 - class형 컴포넌트
class ClassCounter extends Component {
  constructor(props) {
    super(props);
    this.state = { count: 0 }
  }
  componentDidUpdate() {
    //업데이트가 된 이후 1초뒤에 작동
    setTimeout(() => {
      console.log(this.state.count);
    }, 1000)
    return true;
  }
  render() {
    return (
      <>
        <button onClick={function () {
          // this.state.count++;
          this.setState({ count: this.state.count + 1 });
        }.bind(this)}>클래스 count</button>
      </>
    );
  }
}

//라이프 사이클을 활용한 최신 state값 활용 - 함수형 컴포넌트
function FuncCounter() {
  //함수형 컴포넌트에서 최신 state값 활용을 위해 useRef함수를 임의 변수에 저장한다.
  const lastestCount = useRef();

  const [count, setCount] = useState(0);
  useEffect(function () {
    //useRef를 저장한 변수명.current 에 state값을 저장시킨다.
    lastestCount.current = count;
    setTimeout(() => {
      // console.log(count); ->최신상태의 state값이 아닌 클릭했을때 당시의 state값이 순차적으로 출력
      console.log(lastestCount.current); // useEffect에서 최신상태의 state값을 활용
    }, 1000);
  });

  //useEffect함수를 마운트 될때 한번만 실행하도록 작성
  // useEffect함수의 두번째 매개변수에 빈 배열을 추가한다.
  useEffect(function () {
    console.log("FuncComponent의 useEffect 실행 - 마운트 될때 한번만 실행");
  }, []);

  // 특정 상태값이 변경될때만 useEffect 실행
  // useEffect함수의 두번째 매개변수에 특정값을 넣은 배열을 추가한다.
  useEffect(function () {
    console.log("count state값이 변경될때 실행")
  }, [count])

  return (
    <>
      <button onClick={function () {
        setCount(count + 1);
      }}>함수형 count</button>
    </>
  );
}


function App() {
  //컴포넌트 제거를 위한 state 사용 - life cycle의 unmount 실행
  const [show, setShow] = useState(true);
  const [show2, setShow2] = useState(true);
  return (
    <div className="container">
      <h1>Hello World</h1>
      {show ? <ClassComp initNumber={2} /> : null}
      {show2 ? <FuncComp initNumber={2} /> : null}
      <ClassCounter />
      <FuncCounter />
    </div>
  );
}

export default App;
