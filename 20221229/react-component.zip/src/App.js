import './App.css';
import { Component, useState } from 'react';

class ClassComp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      number: this.props.initNumber,
      date: new Date().toString()
    }
  }
  render() {
    // const number = this.props.initNumber;
    return (
      <div className='container'>
        <h2>class형 컴포넌트</h2>
        <p>Number : {this.state.number}</p>
        <button onClick={() => {
          this.setState({ number: Math.random() })
        }}>랜덤</button>
        <p>날짜 : {this.state.date}</p>
        <button onClick={() => {
          this.setState({ date: new Date().toString() });
        }}>날짜갱신</button>
      </div>
    );
  }
}

function FuncComp(props) {//함수의 첫번째 인자값에 props가 담겨져있다.
  // const number = props.initNumber;

  // useState로 생성한 state값에는 두가지 인자가 들어있는데
  // 0번째 항목에는 실제 value값이 들어있고,
  // 1번째 항목에는 해당 state을 변경할수있는 setState함수가 내장되어있다.
  // const numberState = useState(props.initNumber);
  // const number = numberState[0];
  // const setNumber = numberState[1];

  // const [state1 , setState1] = useState(초기값할당);
  // state 에는 상태값이 저장되어있고,
  // setState에는 상태값을 수정할수있는 setState함수가 내장되어있다.
  // setState함수를 호출하면 해당하는 state값이 변경이 된다.(1대1관계)
  const [number, setNumber] = useState(props.initNumber);
  const [date, setDate] = useState(new Date().toString());
  return (
    <div className='container'>
      <h2>Function형 컴포넌트</h2>
      <p>Number : {number}</p>
      <button onClick={() => {
        setNumber(Math.random());
      }}>랜덤</button>
      <p>날짜 : {date}</p>
      <button onClick={() => {
        setDate(new Date().toString());
      }}>날짜갱신</button>
    </div>
  );
}

function App() {
  return (
    <div className="container">
      <h1>Hello World</h1>
      <ClassComp initNumber={2} />
      <FuncComp initNumber={2} />
    </div>
  );
}

export default App;
