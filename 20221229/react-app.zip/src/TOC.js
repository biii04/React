import { Component } from 'react';

class TOC extends Component {
  render() {
    const list = [];
    for (let i = 0; i < this.props.contents.length; i++) {
      list.push(
        //for문으로 <li></li>를 표현할때 key속성을 추가 해줘야한다.
        // key속성에는 유니크한 값을 세팅 해줘야 한다.
        <li key={i}>
          <a href={this.props.contents[i].id + '.html'}
            onClick={(e) => {
              e.preventDefault();
              this.props.onSelect(this.props.contents[i].id);
            }}>
            {this.props.contents[i].title}
          </a>
        </li>
      );
    }
    return (
      <nav>
        <ul>
          {list}
        </ul>
      </nav>


      // <nav>
      //   <ul>
      //     <li>
      //       <a href={this.props.contents[0].id + '.html'}
      //         onClick={(e) => {
      //           e.preventDefault();
      //           this.props.onSelect(this.props.contents[0].id);
      //         }}>
      //         {this.props.contents[0].title}
      //       </a>
      //     </li>
      //     <li>
      //       <a href={this.props.contents[1].id + '.html'}
      //         onClick={function (e) {
      //           e.preventDefault();
      //           this.props.onSelect(this.props.contents[1].id);
      //         }.bind(this)}>
      //         {this.props.contents[1].title}
      //       </a>
      //     </li>
      //     <li>
      //       <a href={this.props.contents[2].id + '.html'}
      //         onClick={(e) => {
      //           e.preventDefault();
      //           this.props.onSelect(this.props.contents[2].id);
      //         }}>
      //         {this.props.contents[2].title}
      //       </a>
      //     </li>
      //   </ul>
      // </nav>
    );
  }
}

export default TOC;