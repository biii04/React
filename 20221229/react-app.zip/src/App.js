import React, { Component } from 'react';
import './App.css'; //css 적용방법
import Subject from './Subject';
import TOC from './TOC';
import ReadContent from './ReadContent';
import Like from './Like';
import Control from './Control';
import CreateContent from './CreateContent';
import UpdateContent from './UpdateContent';

// ctrl + shift + k : 한줄 삭제
// alt + shift + 방향키 위아래 : 한줄 복사
// alt + 방향키 위아래 : 한줄 이동
// ctrl + / : 주석(처리 or 해제)
class App extends Component {
  // state값 생성시 필수항목 : 
  //  생성자(13~15라인까지의 항목들: 생성자,슈퍼생성자,this.state)
  constructor(props) {
    super(props);
    this.state = {
      selected_content_id: 1,
      mode: 'read',
      welcome: { title: 'welcome', desc: 'Hello, React' },
      subject: { title: 'WEB', sub: 'World Wide Web!' },
      contents: [
        { id: 1, title: 'HTML', desc: 'HTML is for information' },
        { id: 2, title: 'CSS', desc: 'CSS is for design' },
        { id: 3, title: 'JavaScript', desc: 'JS is for interactive.' }
      ]
    }
  }

  findContentById(id) {
    let content;
    for (let i = 0; i < this.state.contents.length; i++) {
      if (id === this.state.contents[i].id) {
        //매개변수 id값과 일치하는 contents를 찾으면 content변수에 저장한다.
        content = this.state.contents[i];
        break;//저장이 끝난후 더이상 for문을 실행하지 않아도 되므로 바로 종료
      }
    }
    return content;//저장이 끝난 content변수를 호출한곳으로 반환해준다.
  }

  render() { //state값이 변경이 되면 재호출된다.
    //state의 mode에 따라서 다른내용이 보여지도록 
    // === : 비교연산할때 타입까지 비교 해준다.
    let title, desc, article;
    if (this.state.mode === 'welcome') {
      title = this.state.welcome.title;
      desc = this.state.welcome.desc;
    } else if (this.state.mode === 'read') {
      const content = this.findContentById(this.state.selected_content_id);
      title = content.title;
      desc = content.desc;
    } else if (this.state.mode === 'create') {
      article = <CreateContent onSubmit={function (title, desc) {
        this.state.contents.push({
          id: this.state.contents.length + 1,
          title: title,
          desc: desc
        });
        this.setState({ contents: this.state.contents });
      }.bind(this)} />
    } else if (this.state.mode === 'update') {
      //TOC컴포넌트에서 선택한 항목의 id값을 가져와서 - 1
      // id값을 이용해서 해당 항목의 title, desc값을 읽어온다. - 2
      // UpdateContent 컴포넌트를 article변수에 저장해주는데,
      // title과 desc정보를 props로 전달한다. - 3
      const content = this.findContentById(this.state.selected_content_id);
      title = content.title;
      desc = content.desc;
      article = <UpdateContent title={title} desc={desc}
        onSubmit={function (title, desc) {
          content.title = title;
          content.desc = desc;
          this.setState({ mode: 'read' });
        }.bind(this)} />
    }
    return (
      <div className="App">
        {/* 
          html 태그 형식으로 컴포넌트를 적용
          컴포넌트 : 화면에 출력할 내용(요소) js파일로 생성한것.
          이름생성 규칙 : html태그와 구분을 주기위해서, 첫글자는 대문자로 생성(명명)한다.
        */}
        {/* 
          컴포넌트에 데이터 전달 - props : 
          html에 속성을 부여하듯이 넘겨줄 데이터의 이름을 정한뒤 = 뒤에 실제데이터값을
          설정해준다.
          ex) title='WEB'
        */}
        <Subject title={this.state.subject.title} sub={this.state.subject.sub}
          onChangePage={function () {
            this.setState({ mode: 'welcome' });
          }.bind(this)} />
        <TOC contents={this.state.contents}
          onSelect={(id) => {
            this.setState({
              mode: 'read',
              selected_content_id: id
            });
          }}></TOC>

        {/* CRUD 기능 UI추가 */}
        <Control onChangeMode={function (mode) {
          if (mode === 'delete') {
            const contents = this.state.contents;
            if (window.confirm("정말 삭제하시겠습니까?")) {
              for (let i = 0; i < contents.length; i++) {
                if (contents[i].id === this.state.selected_content_id) {
                  contents.splice(i, 1);
                }
              }
            }
            this.setState({
              mode: 'welcome', contents: contents
            });
          } else {
            this.setState({ mode: mode });
          }
        }.bind(this)} />

        <ReadContent title={title} desc={desc} />

        {/* crud mode에 따라서 article에 저장된 컴포넌트가 다르게 출력 */}
        {article}

        {/* 좋아요기능 UI구현 */}
        {/*  */}
        <Like onLike={function (id) {
          // id가 like인 html요소를 얻어서
          // style의 display속성을 inline으로 변경한다.
          // document.getElementById('like').style.display = 'inline';

          if (id === 'like') { //빨간색 하트가 클릭 되었을때 (좋아요 비활성화)
            document.getElementById('like').style.display = 'none';
            document.getElementById('unlike').style.display = 'inline';
          } else { // 투명한 하트가 클릭 되었을때(좋아요 활성화)
            document.getElementById('like').style.display = 'inline';
            document.getElementById('unlike').style.display = 'none';
          }
        }} />
      </div>
    );
  }
}

export default App;
