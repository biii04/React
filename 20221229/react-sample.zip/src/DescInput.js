import './DescInput.css';
import { Component } from 'react';

class DescInput extends Component {
  render() {
    return (
      <form className='desc-input' onSubmit={function (e) {
        //해당 태그는 form태그이므로 form태그 내에서 특정 html요소의 값을 가져올때
        // name속성을 해당태그에 부여하고, name속에 지정한 값으로
        // 데이터를 가져올수있다.
        // e.target.desc.value -> form태그 내에서 name속성이 desc인 태그의 value값
        // e.target : form태그를 의미(event가 발생하는 태그요소)
        e.preventDefault();
        this.props.onSubmit(e.target.desc.value);
      }.bind(this)}>
        <input type='text' name='desc' />
        <button type='submit'>추가</button>
      </form>
    );
  }
}

export default DescInput;